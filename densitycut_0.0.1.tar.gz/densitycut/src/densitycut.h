#include <R.h>
#include <Rdefines.h>
#include <Rmath.h>

SEXP sexp_log_sum_exp(SEXP x);
double log_sum_exp(const double* x, const size_t n);


