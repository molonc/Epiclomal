.onUnload = function(libpath) {
  library.dynam.unload("densitycut", libpath)
}
